def alphabet(seq: str):
    return sorted(set(seq))

S = "ATTGCC4CCGAAT"
print(alphabet(S)) 