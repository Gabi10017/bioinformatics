import matplotlib.pyplot as plt
import collections

class DNAPatternAnalyzer:
    def __init__(self):
        self.results = []
        self.trajectory_points = []
    
    def calculate_cg_content(self, sequence):
        """
        Step 3: Process CpG content (C+G %).
        Formula: (Count(C) + Count(G)) / Length * 100
        """
        seq = sequence.upper()
        length = len(seq)
        if length == 0:
            return 0.0
        
        c_count = seq.count('C')
        g_count = seq.count('G')
        
        cg_percent = ((c_count + g_count) / length) * 100
        return cg_percent

    def calculate_kappa_ic(self, sequence):
        """
        Step 4: Process Index of Coincidence.
        Formula: Sum(n*(n-1)) / (N*(N-1)) * 100
        """
        seq = sequence.upper()
        N = len(seq)
        if N < 2:
            return 0.0
            
        counts = collections.Counter(seq)
        
        numerator = 0
        for base in ['A', 'C', 'G', 'T']:
            n = counts.get(base, 0)
            numerator += n * (n - 1)
            
        denominator = N * (N - 1)
        
        ic = (numerator / denominator) * 100
        return ic

    def analyze_sequence(self, sequence, window_size=30):
        """
        Step 2: Sliding window analysis.
        """
        self.trajectory_points = []
        seq_len = len(sequence)
        
        # If sequence is shorter than window, analyze the whole thing once
        if seq_len < window_size:
            cg = self.calculate_cg_content(sequence)
            ic = self.calculate_kappa_ic(sequence)
            self.trajectory_points.append((cg, ic))
            return

        # Sliding window
        # Range is 0 to (Length - Window + 1)
        for i in range(seq_len - window_size + 1):
            sub_seq = sequence[i : i + window_size]
            cg = self.calculate_cg_content(sub_seq)
            ic = self.calculate_kappa_ic(sub_seq)
            self.trajectory_points.append((cg, ic))

    def calculate_center_of_weight(self):
        """
        Step 6: Calculate the center of weight (Centroid) of the pattern.
        """
        if not self.trajectory_points:
            return (0, 0)
            
        total_cg = sum(p[0] for p in self.trajectory_points)
        total_ic = sum(p[1] for p in self.trajectory_points)
        count = len(self.trajectory_points)
        
        return (total_cg / count, total_ic / count)

    def plot_patterns(self, sequence_name="Test Sequence"):
        """
        Plots the data in two ways:
        1. Linear Style (Position vs Value) - similar to the friend's plot.
        2. Center of Weight (CG vs IC) - showing the centroid of the pattern.
        """
        if not self.trajectory_points:
            print("No data to plot.")
            return

        # Extract X (Window Positions) and Y values (CG and IC)
        window_positions = range(len(self.trajectory_points))
        cg_values = [p[0] for p in self.trajectory_points]
        ic_values = [p[1] for p in self.trajectory_points]
        
        centroid = self.calculate_center_of_weight()
        
        # Create a figure with two subplots side-by-side
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))
        
        # --- Chart 1: Linear View (Friend's Style) ---
        # Plot C+G % (Blue line)
        ax1.plot(window_positions, cg_values, label='C+G %', color='blue')
        # Plot Kappa IC (Red line)
        ax1.plot(window_positions, ic_values, label='Kappa IC', color='red')
        
        ax1.set_title('1. Linear View: C+G% and Kappa IC')
        ax1.set_xlabel('Window Position')
        ax1.set_ylabel('Value')
        ax1.legend(loc='upper right')
        ax1.grid(True)
        
        # --- Chart 2: Center of Weight (Centroid View) ---
        # To visualize the center, we need the 2D context (CG vs IC)
        # We plot the trajectory faintly so the center point makes sense
        ax2.plot(cg_values, ic_values, color='gray', alpha=0.3, label='Pattern Path')
        ax2.scatter(centroid[0], centroid[1], color='purple', s=200, marker='X', label='Center of Weight')
        
        # Add label for the centroid
        ax2.text(centroid[0], centroid[1] + 1, 
                 f'Center:\nCG={centroid[0]:.2f}\nIC={centroid[1]:.2f}', 
                 ha='center', fontsize=10, bbox=dict(facecolor='white', alpha=0.8))
        
        ax2.set_title('2. Center of Weight (Centroid)')
        ax2.set_xlabel('C+G Content (%)')
        ax2.set_ylabel('Kappa IC')
        ax2.legend(loc='upper right')
        ax2.grid(True, linestyle='--', alpha=0.7)

        plt.tight_layout()
        plt.show()

def main():
    # 1. Input Sequence
    S = "CGGACTGATCTATCTAAAAAAAAAAAAAAAAAAAAAAAAAAACGTAGCATCTATCGATCTATCTAGCGATCTATCTACTACG"
    
    analyzer = DNAPatternAnalyzer()
    
    print("-" * 50)
    print("RUNNING ANALYSIS")
    print("-" * 50)
    
    # 2. Sliding Window Analysis
    analyzer.analyze_sequence(S, window_size=30)
    
    # 3. Plotting
    print("Generating plots (Linear View + Center of Weight)...")
    analyzer.plot_patterns(sequence_name="Input Promoter Sequence")

if __name__ == "__main__":
    main()