from Bio import Entrez, SeqIO
import matplotlib.pyplot as plt
import numpy as np

Entrez.email = "tudorarhir@gmail.com"

influenza_accessions = [
    ("AF117241", "Flu 1918 H1N1"),
    ("CY044365", "Flu 2009 H1N1"),
    ("DQ266097", "Flu 1972 H3N2"),
    ("EF541403", "Flu H5N1 Viet"),
    ("KC858139", "Flu H7N9 Anhui"),
    ("AY651334", "Flu H9N2 Korea"),
    ("CY009452", "Flu 1934 H1N1"),
    ("CY163680", "Flu 2017 H3N2"),
    ("KM244078", "Flu H10N8 Jiang"),
    ("JX849137", "Flu H3N8 Seal")
]

covid_accessions = [
    ("NC_045512", "SARS2 Wuhan"),
    ("MW595908", "SARS2 Alpha"),
    ("MW598419", "SARS2 Beta"),
    ("MZ202178", "SARS2 Gamma"),
    ("OK091006", "SARS2 Delta"),
    ("OM287553", "SARS2 Omic BA1"),
    ("OQ347209", "SARS2 Omic XBB"),
    ("MT007544", "SARS2 Aus"),
    ("MT291827", "SARS2 USA WA1"),
    ("MT039890", "SARS2 Korea")
]

def fetch_sequence(acc_id):
    try:
        handle = Entrez.efetch(db="nucleotide", id=acc_id, rettype="fasta", retmode="text")
        record = SeqIO.read(handle, "fasta")
        handle.close()
        return str(record.seq).upper()
    except:
        return None

def calculate_metrics(sequence, window_size=150):
    cg_list = []
    ic_list = []
    seq_len = len(sequence)
    
    for i in range(0, seq_len - window_size + 1):
        window = sequence[i:i+window_size]
        
        c_count = window.count('C')
        g_count = window.count('G')
        cg_val = ((c_count + g_count) / window_size) * 100
        cg_list.append(cg_val)
        
        counts = {base: window.count(base) for base in ['A', 'C', 'G', 'T']}
        numerator = sum(c * (c - 1) for c in counts.values())
        denominator = window_size * (window_size - 1)
        ic_val = (numerator / denominator) * 100 if denominator > 0 else 0
        ic_list.append(ic_val)
        
    return cg_list, ic_list

def get_centroid(cg_data, ic_data):
    return np.mean(cg_data), np.mean(ic_data)

plt.figure(figsize=(12, 10))
ax1 = plt.subplot(1, 1, 1)

centroids = []

print("Processing Influenza Genomes (HA Segment)...")
for acc, name in influenza_accessions:
    seq = fetch_sequence(acc)
    if seq:
        cg, ic = calculate_metrics(seq)
        c_cg, c_ic = get_centroid(cg, ic)
        centroids.append((name, c_cg, c_ic, 'blue'))
        ax1.scatter(cg, ic, alpha=0.05, color='cyan', s=1)

print("Processing COVID-19 Genomes...")
for acc, name in covid_accessions:
    seq = fetch_sequence(acc)
    if seq:
        cg, ic = calculate_metrics(seq)
        c_cg, c_ic = get_centroid(cg, ic)
        centroids.append((name, c_cg, c_ic, 'red'))
        ax1.scatter(cg, ic, alpha=0.05, color='orange', s=1)

ax1.set_title('Objective Digital Stains (ODS): Influenza (Cyan) vs COVID-19 (Orange)')
ax1.set_xlabel('C+G %')
ax1.set_ylabel('Kappa Index of Coincidence')
ax1.grid(True)
plt.show()

plt.figure(figsize=(14, 9))
ax2 = plt.subplot(1, 1, 1)

covid_labels = []
flu_cluster_labels = []

for name, x, y, color in centroids:
    ax2.scatter(x, y, color=color, s=120, edgecolors='black', linewidth=0.5)
    
    if color == 'red':
        covid_labels.append((name, x, y))
    elif x < 44:
        flu_cluster_labels.append((name, x, y))
    else:
        ax2.text(x + 0.3, y, name, fontsize=9, fontweight='bold')

if covid_labels:
    covid_labels.sort(key=lambda k: k[2], reverse=True)
    base_y = 26.8
    text_x = 38.5
    
    for i, (name, x, y) in enumerate(covid_labels):
        text_y = base_y - (i * 0.12)
        ax2.text(text_x, text_y, name, fontsize=8, color='darkred')
        ax2.plot([x, text_x - 0.1], [y, text_y + 0.02], color='red', linestyle='--', linewidth=0.5, alpha=0.5)

if flu_cluster_labels:
    flu_cluster_labels.sort(key=lambda k: k[2], reverse=True)
    base_y = 26.8
    text_x = 43.5
    
    for i, (name, x, y) in enumerate(flu_cluster_labels):
        text_y = base_y - (i * 0.12)
        ax2.text(text_x, text_y, name, fontsize=8, color='darkblue')
        ax2.plot([x, text_x - 0.1], [y, text_y + 0.02], color='blue', linestyle='--', linewidth=0.5, alpha=0.5)

ax2.set_title('Center of Weight (Centroids) - Label Stack View')
ax2.set_xlabel('Average C+G %')
ax2.set_ylabel('Average Kappa IC')
ax2.grid(True)
plt.show()