This folder is dedicated to lab exercises on December 18/Lab12. 

Please find the plots and their matrix in .csv files. 

Contributors: Danaila Gabriel 1242EA



![Output Ex1](./images/sliding_window_score_plot.png)
![Output Ex2](./images/influenza_genome_scan.png)