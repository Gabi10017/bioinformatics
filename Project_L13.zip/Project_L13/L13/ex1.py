import numpy as np

class DiscreteStepPredictor:
    def __init__(self, matrix, initial_vector):
        """
        Initialize the predictor with a square matrix and an initial vector.
        
        Args:
            matrix (list or np.array): A square transition matrix (NxN).
            initial_vector (list or np.array): The starting state vector (N).
        """
        self.A = np.array(matrix, dtype=float)
        self.x = np.array(initial_vector, dtype=float)
        
        self._validate_inputs()

    def _validate_inputs(self):
        """Checks if matrix is square and vector dimensions match."""
        rows, cols = self.A.shape
        vec_len = self.x.shape[0]

        if rows != cols:
            raise ValueError(f"Matrix must be square. Received dimensions: {rows}x{cols}")
        
        if cols != vec_len:
            raise ValueError(f"Vector dimension ({vec_len}) does not match matrix columns ({cols}).")

    def predict(self, steps=5):
        """
        Performs the prediction for a specific number of discrete steps.
        
        Args:
            steps (int): Number of steps to predict. Default is 5.
            
        Returns:
            list: A list of vectors representing the state at each step [step_1, ..., step_n].
        """
        current_state = self.x.copy()
        history = []

        print(f"--- Starting Prediction (Initial State: {current_state}) ---")

        for i in range(1, steps + 1):
            # Calculate the next state: x(k+1) = A * x(k)
            # The @ symbol is the numpy operator for matrix multiplication
            next_state = self.A @ current_state
            
            # Store and update
            history.append(next_state)
            current_state = next_state
            
            print(f"Step {i}: {np.round(next_state, 4)}")
            
        return history

# --- Example Usage / Driver Code ---

if __name__ == "__main__":
    # Example 1: A simple 2x2 System (e.g., Population migration or Weather probabilities)
    # This matrix implies: 
    # - 90% of A stays in A, 10% goes to B
    # - 50% of B goes to A, 50% stays in B
    matrix_size_2 = [
        [0.9, 0.5],
        [0.1, 0.5]
    ]
    vector_start_2 = [100, 50] # e.g., 100 people in city A, 50 in city B

    print("=== Test Case 1: 2x2 Matrix ===")
    try:
        app = DiscreteStepPredictor(matrix_size_2, vector_start_2)
        results = app.predict(steps=5)
    except ValueError as e:
        print(f"Error: {e}")

    print("\n" + "="*30 + "\n")

    # Example 2: Arbitrary 3x3 System
    matrix_size_3 = [
        [1, 0.5, 0.2],
        [0, 0.5, 0.3],
        [0, 0,   0.5]
    ]
    vector_start_3 = [10, 20, 30]

    print("=== Test Case 2: 3x3 Matrix ===")
    try:
        app3 = DiscreteStepPredictor(matrix_size_3, vector_start_3)
        app3.predict(steps=5)
    except ValueError as e:
        print(f"Error: {e}")