import random
import json
import string

class TransitionMatrixGenerator:
    def __init__(self):
        pass

    def normalize_counts(self, counts):
        """Converts raw transition counts into probabilities."""
        probability_matrix = {}
        
        for current_state, next_states in counts.items():
            total_transitions = sum(next_states.values())
            probability_matrix[current_state] = {}
            
            if total_transitions > 0:
                for next_state, count in next_states.items():
                    # Round to 4 decimals for cleaner JSON
                    probability_matrix[current_state][next_state] = round(count / total_transitions, 4)
            else:
                probability_matrix[current_state] = {}
                
        return probability_matrix

    def generate_dna_matrix(self, length=50, filename="dna_matrix.json"):
        print(f"--- Generating DNA Matrix (Length: {length}) ---")
        
        # 1. Generate Random DNA Sequence
        bases = ['A', 'C', 'G', 'T']
        sequence = ''.join(random.choice(bases) for _ in range(length))
        print(f"Sequence: {sequence}")

        # 2. Count Transitions
        transitions = {b: {b2: 0 for b2 in bases} for b in bases}
        
        for i in range(len(sequence) - 1):
            current_nuc = sequence[i]
            next_nuc = sequence[i+1]
            transitions[current_nuc][next_nuc] += 1

        # 3. Normalize to Probabilities
        matrix = self.normalize_counts(transitions)

        # 4. Save to JSON
        with open(filename, 'w') as f:
            json.dump(matrix, f, indent=4)
        print(f"Saved to {filename}\n")

    def generate_text_matrix(self, text_length=300, filename="text_matrix.json"):
        print(f"--- Generating Text Matrix (Target Length: ~{text_length}) ---")
        
        # 1. Create a dummy English text (approx 300 chars)
        # Using a repeating coherent sentence to ensure valid word transitions exist
        base_text = "The quick brown fox jumps over the lazy dog. The dog barks at the fox. " \
                    "Wait, the fox is fast. The dog is slow. Time flies like an arrow. " \
                    "Fruit flies like a banana. The quick brown fox is back again. "
        
        # Repeat until we reach ~300 chars
        text = (base_text * 5)[:text_length]
        
        # Ensure we don't cut a word in half at the end
        if ' ' in text:
            text = text.rsplit(' ', 1)[0]
            
        print(f"Text Sample: {text[:60]}... (Total len: {len(text)})")

        # 2. Tokenize (Split into words)
        words = text.split()
        
        # 3. Map unique words to ASCII Symbols (A, B, C...)
        unique_words = sorted(list(set(words)))
        
        # Create mapping: Word -> Symbol
        # We use chr(65) onwards for 'A', 'B', etc.
        word_to_symbol = {}
        symbol_to_word = {}
        
        for index, word in enumerate(unique_words):
            # Using printable ASCII starting from 'A' (65)
            # If > 50 words, this extends into other ascii chars which is fine
            symbol = chr(65 + index) 
            word_to_symbol[word] = symbol
            symbol_to_word[symbol] = word

        # 4. Count Transitions using Symbols
        # Initialize dictionary for all known symbols
        all_symbols = list(word_to_symbol.values())
        transitions = {s: {s2: 0 for s2 in all_symbols} for s in all_symbols}

        for i in range(len(words) - 1):
            curr_sym = word_to_symbol[words[i]]
            next_sym = word_to_symbol[words[i+1]]
            transitions[curr_sym][next_sym] += 1

        # 5. Normalize
        matrix = self.normalize_counts(transitions)

        # 6. Save JSON (Including the Legend)
        output_data = {
            "legend_mapping": symbol_to_word,
            "transition_matrix": matrix
        }
        
        with open(filename, 'w') as f:
            json.dump(output_data, f, indent=4)
        print(f"Saved to {filename}")

# --- Execution ---
if __name__ == "__main__":
    generator = TransitionMatrixGenerator()
    
    # Task 1: DNA
    generator.generate_dna_matrix()
    
    # Task 2: English Text
    generator.generate_text_matrix()