import json
import random

class MarkovChainEngine:
    def __init__(self, json_file):
        with open(json_file, 'r') as f:
            data = json.load(f)
            
        # Check if this is the text matrix (has legend) or DNA matrix (flat)
        if "legend_mapping" in data:
            self.matrix = data["transition_matrix"]
            self.legend = data["legend_mapping"]
            self.is_text = True
            # Invert legend for looking up start words: Word -> Symbol
            self.word_to_symbol = {v: k for k, v in self.legend.items()}
        else:
            self.matrix = data
            self.legend = None
            self.is_text = False

    def _select_next_state(self, current_state):
        """
        The 'Engine' logic:
        1. Look up probabilities for current_state.
        2. Create a weighted pool (the 'string' concept).
        3. Pick one random winner.
        """
        if current_state not in self.matrix:
            return None # Dead end

        possible_transitions = self.matrix[current_state]
        
        # --- The "Simple String" Method Implementation ---
        # We create a list (acting as our string) where states appear 
        # proportional to their probability.
        # e.g. {'A': 0.1, 'B': 0.9} -> ['A', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B']
        
        pool = []
        for state, prob in possible_transitions.items():
            # Multiply by 100 to get an integer count (assuming 2 decimal precision is enough for this demo)
            count = int(prob * 100)
            pool.extend([state] * count)
            
        if not pool:
            return None
            
        # Pick one random item from the pool
        return random.choice(pool)

    def synthesize(self, start_item=None, length=20):
        """
        Jumps between states to build a sequence.
        """
        # 1. Determine Start State
        if start_item:
            if self.is_text:
                # User gave a word (e.g., "The"), we need the symbol (e.g., "B")
                current_state = self.word_to_symbol.get(start_item)
                if not current_state:
                    raise ValueError(f"Start word '{start_item}' not found in legend.")
            else:
                current_state = start_item
        else:
            # Pick a random starting point
            current_state = random.choice(list(self.matrix.keys()))

        sequence = []
        
        # Record initial state
        if self.is_text:
            sequence.append(self.legend[current_state])
        else:
            sequence.append(current_state)

        # 2. Run the Engine Loop
        print(f"--- Synthesizing (Start: {sequence[0]}) ---")
        
        for _ in range(length - 1):
            next_state = self._select_next_state(current_state)
            
            if next_state is None:
                break
                
            # Record the jump
            if self.is_text:
                word = self.legend[next_state]
                sequence.append(word)
            else:
                sequence.append(next_state)
                
            # Update pointer for next iteration
            current_state = next_state

        return sequence

# --- Execution ---

# 1. Generate Text Sequence
try:
    text_engine = MarkovChainEngine('text_matrix.json')
    # Let's start with "The" (which is state 'B' or '[')
    result = text_engine.synthesize(start_item="The", length=15)
    print("\nGenerated Text:")
    print(" ".join(result))
except FileNotFoundError:
    print("Please generate text_matrix.json first using your ex2.py")

print("-" * 30)

# 2. Generate DNA Sequence
try:
    dna_engine = MarkovChainEngine('dna_matrix.json')
    result_dna = dna_engine.synthesize(start_item="A", length=50)
    print("\nGenerated DNA:")
    print("".join(result_dna))
except FileNotFoundError:
    print("Please generate dna_matrix.json first using your ex2.py")