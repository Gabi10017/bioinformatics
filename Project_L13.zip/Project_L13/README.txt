Arhir Tudor Danaila Gabriel
the output for ex2 are stored in the json files in the folder L13