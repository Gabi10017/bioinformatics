import math
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

# ---------------------------------------------------------
# INPUT DATA FROM THE ASSIGNMENT
# ---------------------------------------------------------
# S1: Known to belong to CpG Island (+)
s1_plus = "ATCGATTCGATATCATACACGTAT"

# S2: Known to belong to other regions (-)
s2_minus = "CTCGACTAGTATGAAGTCCACGCTTG"

# S_test: The new sequence to classify
s_test = "CAGGTTGGAAACGTAA"

# The four nucleotides
nucleotides = ['A', 'C', 'G', 'T']

# ---------------------------------------------------------
# STEP 1 & 2: COUNT TRANSITION FREQUENCIES
# ---------------------------------------------------------
def count_transitions(sequence, alphabet):
    counts = {n: {m: 0 for m in alphabet} for n in alphabet}
    for i in range(len(sequence) - 1):
        current_n = sequence[i]
        next_n = sequence[i+1]
        counts[current_n][next_n] += 1
    return counts

# ---------------------------------------------------------
# CALCULATE PROBABILITIES
# ---------------------------------------------------------
def calculate_probabilities(counts, alphabet):
    probs = {n: {m: 0.0 for m in alphabet} for n in alphabet}
    for row in alphabet:
        total_transitions = sum(counts[row].values())
        if total_transitions > 0:
            for col in alphabet:
                probs[row][col] = counts[row][col] / total_transitions
    return probs

# ---------------------------------------------------------
# STEP 3: MAKE LOG LIKELIHOOD MATRIX
# ---------------------------------------------------------
def create_log_likelihood_matrix(probs_plus, probs_minus, alphabet):
    ll_matrix = {n: {m: 0.0 for m in alphabet} for n in alphabet}
    for row in alphabet:
        for col in alphabet:
            p_plus = probs_plus[row][col]
            p_minus = probs_minus[row][col]
            
            # Handle log(0) by assigning a large penalty/reward
            if p_plus == 0 and p_minus == 0: score = 0.0
            elif p_plus == 0: score = -999.0
            elif p_minus == 0: score = 999.0
            else: score = math.log2(p_plus / p_minus)
            
            ll_matrix[row][col] = score
    return ll_matrix

# ---------------------------------------------------------
# EXECUTE CALCULATIONS
# ---------------------------------------------------------
counts_plus = count_transitions(s1_plus, nucleotides)
counts_minus = count_transitions(s2_minus, nucleotides)
probs_plus = calculate_probabilities(counts_plus, nucleotides)
probs_minus = calculate_probabilities(counts_minus, nucleotides)
ll_matrix = create_log_likelihood_matrix(probs_plus, probs_minus, nucleotides)

# ---------------------------------------------------------
# GENERATE THE HEATMAP INTERFACE
# ---------------------------------------------------------
def plot_heatmap(matrix, alphabet):
    # Convert dictionary to a numpy array for plotting
    data = np.array([[matrix[n][m] for m in alphabet] for n in alphabet])
    
    # Create a copy for visualization, clamping extreme values
    # so they don't distort the color scale.
    plot_data = data.copy()
    plot_data[plot_data > 5] = 5
    plot_data[plot_data < -5] = -5

    # Set up the matplotlib figure
    fig, ax = plt.subplots(figsize=(8, 6))
    
    # Create the heatmap using seaborn
    sns.heatmap(plot_data, annot=True, fmt=".3f", cmap="coolwarm",
                xticklabels=alphabet, yticklabels=alphabet,
                cbar_kws={'label': 'Log-Likelihood Score'}, ax=ax)
    
    # Add titles and labels
    ax.set_title("Log-Likelihood Matrix\n(CpG Island vs Background)")
    ax.set_ylabel("From Nucleotide", fontsize=12)
    ax.set_xlabel("To Nucleotide", fontsize=12)
    
    # Display the plot
    plt.show()

# Show the matrix interface
plot_heatmap(ll_matrix, nucleotides)

# ---------------------------------------------------------
# CLASSIFY THE TEST SEQUENCE S
# ---------------------------------------------------------
print(f"\n--- Classifying Sequence S: {s_test} ---")
total_score = 0
for i in range(len(s_test) - 1):
    n1 = s_test[i]
    n2 = s_test[i+1]
    score = ll_matrix[n1][n2]
    total_score += score
    
print(f"Total Log-Likelihood Score: {total_score:.4f}")

if total_score > 0:
    print("Result: Sequence IS a CpG Island (Score is positive).")
else:
    print("Result: Sequence is NOT a CpG Island (Score is negative).")