import math
import matplotlib.pyplot as plt
import re

# Snippet from "Luceafărul" (Mihai Eminescu)
text_eminescu = """
Cobori în jos, luceafăr blând,
Alunecând pe-o rază,
Pătrunde-n casă și în gând
Și viața-mi luminează!
El asculta tremurător,
Se aprindea mai tare
Și s-arunca fulgerător
Se cufunda în mare;
Și apa unde-au căzut
În cercuri se rotește,
Și din adânc necunoscut
Un mândru tânăr crește.
"""

# Snippet from "Leoaica tânără, iubirea" (Nichita Stănescu)
text_stanescu = """
Leoaica tânără, iubirea
mi-a sărit în faţă.
Mă pândise-n încordare
mai demult.
Colţii albi mi i-a înfipt în faţă,
m-a muşcat leoaica, azi, de faţă.
Şi deodată-n jurul meu, natura
se făcu un cerc, de-a-dura,
când mai larg, când mai aproape,
ca o strângere de ape.
"""

# We combine lines from Eminescu, then Stanescu, then Eminescu again.
# "Mihai" (the accused) copied snippets from both.
text_accused = """
Leoaica tânără, iubirea
Alunecând pe-o rază,
Mă pândise-n încordare
Și viața-mi luminează!
Mai demult.
Pătrunde-n casă și în gând
Colţii albi mi i-a înfipt în faţă
Un mândru tânăr crește.
"""

def clean_and_tokenize(text):
    # Convert to lowercase and remove punctuation
    text = text.lower()
    # Keep only alphanumeric and spaces (simple cleaning)
    text = re.sub(r'[^\w\s]', '', text)
    # Split by whitespace
    return text.split()

def build_transition_counts(tokens):
    counts = {}
    for i in range(len(tokens) - 1):
        current_word = tokens[i]
        next_word = tokens[i+1]
        
        if current_word not in counts:
            counts[current_word] = {}
        
        if next_word not in counts[current_word]:
            counts[current_word][next_word] = 0
            
        counts[current_word][next_word] += 1
    return counts

def calculate_probabilities(counts):
    probs = {}
    for word, transitions in counts.items():
        total = sum(transitions.values())
        probs[word] = {next_w: count/total for next_w, count in transitions.items()}
    return probs

tokens_eminescu = clean_and_tokenize(text_eminescu)
tokens_stanescu = clean_and_tokenize(text_stanescu)

# Build Matrices
probs_eminescu = calculate_probabilities(build_transition_counts(tokens_eminescu))
probs_stanescu = calculate_probabilities(build_transition_counts(tokens_stanescu))


def get_transition_score(w1, w2):
    # Get probability in Eminescu (Model A)
    p_e = probs_eminescu.get(w1, {}).get(w2, 0)
    
    # Get probability in Stanescu (Model B)
    p_s = probs_stanescu.get(w1, {}).get(w2, 0)
    
    # Logic from previous assignment:
    if p_e == 0 and p_s == 0: return 0      # Neither knows this transition
    if p_e == 0: return -10.0               # Strong Stanescu signal (Negative)
    if p_s == 0: return 10.0                # Strong Eminescu signal (Positive)
    
    return math.log2(p_e / p_s)

accused_tokens = clean_and_tokenize(text_accused)
window_size = 5
scores = []
x_labels = []

# Scan the text
for i in range(len(accused_tokens) - 1):
    w1 = accused_tokens[i]
    w2 = accused_tokens[i+1]
    

    score = get_transition_score(w1, w2)
    
    scores.append(score)
    x_labels.append(f"{w1} {w2}")

window_scores = []
current_sum = 0
for i in range(len(scores)):
    start = max(0, i-2)
    window = scores[start : i+1]
    avg = sum(window) / len(window)
    window_scores.append(avg)

plt.figure(figsize=(12, 6))

# Plot the scores
plt.plot(window_scores, marker='o', linestyle='-', color='purple', linewidth=2)

# Add a horizontal line at 0 (The Neutral Zone)
plt.axhline(y=0, color='black', linestyle='--', linewidth=1)

# Color the zones
plt.fill_between(range(len(window_scores)), window_scores, 0, where=[x > 0 for x in window_scores], color='blue', alpha=0.3, label='Eminescu Zone (+)')
plt.fill_between(range(len(window_scores)), window_scores, 0, where=[x < 0 for x in window_scores], color='red', alpha=0.3, label='Stanescu Zone (-)')

# Labels
plt.xticks(range(len(x_labels)), x_labels, rotation=45, ha='right', fontsize=8)
plt.title("Plagiarism Detection: Eminescu (+) vs. Stanescu (-)")
plt.ylabel("Log-Likelihood Score")
plt.xlabel("Text Transitions (Scanning the Accused Text)")
plt.legend()
plt.tight_layout()

print("--- COURTROOM REPORT ---")
print("Blue Zone (> 0): High probability of Eminescu style.")
print("Red Zone (< 0): High probability of Stanescu style.")
print("Generating evidence graph...")

plt.show()