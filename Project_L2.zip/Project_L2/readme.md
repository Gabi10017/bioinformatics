This lab represents the computing the percentage of dinucleotides and trinucleotides. 09.10.2025

<To run the script please type: python labx_x.py>

Contributors: Danaila Gabriel

Gabriel Danaila - bioinfo repo: https://github.com/Gabi10017/bioinformatics