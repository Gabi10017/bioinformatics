from Bio import Entrez, SeqIO
import random
import time
import matplotlib.pyplot as plt

# Accession IDs and virus names
virus_data = [
    ('MN908947.3', 'SARS-CoV-2'),
    ('CY121680', 'Influenza A'),
    ('K03455', 'HIV-1'),
    ('NC_007605', 'Epstein-Barr'),
    ('AF266288', 'Measles'),
    ('NC_012532', 'Zika'),
    ('V01149', 'Poliovirus'),
    ('V00866', 'Hepatitis B'),
    ('NC_001526', 'HPV-16'),
    ('AY502009', 'Norovirus'),
]

# Provide your email for NCBI Entrez
Entrez.email = 'your.email@example.com'

gc_content_list = []
assembly_times = []
names = []

for acc, name in virus_data:
    # 1. Download sequence from NCBI
    handle = Entrez.efetch(db='nucleotide', id=acc, rettype='fasta', retmode='text')
    record = SeqIO.read(handle, 'fasta')
    seq = str(record.seq)
    handle.close()

    # 2. Collect samples
    sample_count = 2000
    samples = []
    for _ in range(sample_count):
        sample_len = random.randint(100, 150)
        start_pos = random.randint(0, len(seq) - sample_len)
        samples.append(seq[start_pos:start_pos + sample_len])

    # 3. Measure assembly time
    start_time = time.perf_counter()
    reconstructed = ''.join(samples)
    end_time = time.perf_counter()
    assembly_time_ms = (end_time - start_time) * 1000  # ms

    # 4. Compute GC content (%)
    gc_counts = seq.count('G') + seq.count('C')
    gc_percentage = 100 * gc_counts / len(seq)

    # Store results
    names.append(name)
    gc_content_list.append(gc_percentage)
    assembly_times.append(assembly_time_ms)

# 5. Plot
import matplotlib.pyplot as plt

plt.figure(figsize=(12, 8), dpi=120)

# Choose different colors and markers for each virus (optional)
colors = plt.cm.tab10(range(len(names)))  # Up to 10 distinct colors
markers = ['o', 's', '^', 'D', 'v', 'P', '*', 'X', 'H', '+']

for i in range(len(names)):
    plt.scatter(
        gc_content_list[i],
        assembly_times[i],
        color=colors[i],
        marker=markers[i % len(markers)],
        s=180,  # Large points
        label=names[i],
        alpha=0.8,
        edgecolors='black'
    )
    plt.annotate(
        names[i],
        (gc_content_list[i], assembly_times[i]),
        textcoords="offset points",
        xytext=(5,5),
        ha='left',
        fontsize=12,
        bbox=dict(boxstyle="round,pad=0.2", fc="white", ec="gray", lw=0.8, alpha=0.8)
    )

plt.xlabel('C+G Percentage (%)', fontsize=15)
plt.ylabel('Assembly Time (ms)', fontsize=15)
plt.title('Genome Assembly Time vs GC Content', fontsize=17)
plt.grid(True, linewidth=0.4, alpha=0.6)
plt.tick_params(axis='both', which='major', labelsize=13)
plt.tight_layout()
plt.xlim(min(gc_content_list) - 2, max(gc_content_list) + 2)
plt.ylim(min(assembly_times) - 0.02, max(assembly_times) + 0.02)
# Optionally: plt.legend(fontsize=12, loc='upper left')  # If you want a legend
plt.show()

