import random

class TransposonSimulation:
    def __init__(self):
        self.IR_LEFT = "GTCCAG"   
        self.IR_RIGHT = "CTGGAC" 
        self.TSD_LENGTH = 4      
    
    def generate_random_dna(self, length):
        """Generates a random string of nucleotides."""
        return "".join(random.choice("ACGT") for _ in range(length))

    def create_sequence_with_transposons(self, base_length=250, num_elements=3):
        """
        Creates a host sequence and inserts transposable elements (TEs).
        """
        
        dna_sequence = self.generate_random_dna(base_length)
        ground_truth_log = [] 

        print(f"--- Step 1: Generating {base_length}bp Host DNA ---")

        
        for i in range(num_elements):
            
            te_body_len = random.randint(20, 40)
            te_body = self.generate_random_dna(te_body_len)
            
            
            transposon_seq = self.IR_LEFT + te_body + self.IR_RIGHT
            
           
            insert_pos = random.randint(10, len(dna_sequence) - 10)
            
            
            target_site = dna_sequence[insert_pos : insert_pos + self.TSD_LENGTH]
            
            
            insertion_block = transposon_seq + target_site
            
            
            dna_sequence = dna_sequence[:insert_pos + self.TSD_LENGTH] + transposon_seq + dna_sequence[insert_pos + self.TSD_LENGTH:]
            
            actual_start = insert_pos + self.TSD_LENGTH
            actual_end = actual_start + len(transposon_seq)
            
            ground_truth_log.append({
                "id": i+1,
                "start_index": actual_start,
                "end_index": actual_end,
                "sequence_snippet": transposon_seq[:10] + "..."
            })
            
            print(f"Inserted TE #{i+1} at index {actual_start}. (Target Site: {target_site})")

        return dna_sequence, ground_truth_log

    def detect_transposons(self, dna_seq):
        """
        Scans the DNA sequence to find the Transposons defined by the class configuration.
        """
        detected_elements = []
        seq_len = len(dna_seq)
        ir_len = len(self.IR_LEFT)
        
        print("\n--- Step 2: Scanning for Transposable Elements ---")
        
        for i in range(seq_len - ir_len):
            if dna_seq[i : i + ir_len] == self.IR_LEFT:
                
                for j in range(i + ir_len, min(i + 100, seq_len - ir_len)):
                    
                    if dna_seq[j : j + ir_len] == self.IR_RIGHT:
                        te_start = i
                        te_end = j + ir_len
                        

                        tsd_left_start = te_start - self.TSD_LENGTH
                        tsd_left = dna_seq[tsd_left_start : te_start]
                        
                        tsd_right_start = te_end
                        tsd_right = dna_seq[tsd_right_start : tsd_right_start + self.TSD_LENGTH]
                        
                        if tsd_left == tsd_right:
                            detected_elements.append({
                                "start": te_start,
                                "end": te_end,
                                "tsd_sequence": tsd_left
                            })
                            break 
                            
        return detected_elements


sim = TransposonSimulation()


final_dna, true_positions = sim.create_sequence_with_transposons(base_length=300, num_elements=3)

print(f"\nFinal Sequence Length: {len(final_dna)} bp")
print(f"Sequence (truncated): {final_dna[:50]}...{final_dna[-50:]}")


detected_results = sim.detect_transposons(final_dna)


print("\n--- Report ---")
print(f"{'Type':<15} | {'Start':<5} | {'End':<5} | {'TSD Detected'}")
print("-" * 45)

for res in detected_results:
    print(f"{'Detected TE':<15} | {res['start']:<5} | {res['end']:<5} | {res['tsd_sequence']}")

print("-" * 45)
print("Verification (Ground Truth):")
for truth in true_positions:
    print(f"TE #{truth['id']} was inserted at {truth['start_index']} - {truth['end_index']}")