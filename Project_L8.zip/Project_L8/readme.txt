Danaila Gabriel

the full output for ex2 is in the L8 folder