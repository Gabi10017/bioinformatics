import random
import re
import matplotlib.pyplot as plt
import numpy as np

class RestrictionEnzyme:
    def __init__(self, name, sequence, cut_index):
        """
        name: Name of the enzyme (e.g., 'EcoRI')
        sequence: 5' to 3' recognition sequence (e.g., 'GAATTC')
        cut_index: The index within the sequence where the cut occurs.
                   (0-based index. e.g., for G|AATTC, cut_index is 1)
        """
        self.name = name
        self.sequence = sequence.upper()
        self.cut_index = cut_index

    def digest(self, dna_sequence):
        """
        Simulates the digestion of linear DNA.
        Returns a list of fragment lengths and the specific cut positions.
        """
        dna_sequence = dna_sequence.upper()
        cut_positions = []
        
        # Find all occurrences of the recognition sequence
        # We use a lookahead assertion (?=...) to handle overlapping sites if necessary, 
        # though standard restriction sites rarely overlap in a way that allows double cutting.
        # For this exercise, simple iteration is sufficient.
        
        for match in re.finditer(self.sequence, dna_sequence):
            # The physical cut happens at start_index + cut_index
            cut_pos = match.start() + self.cut_index
            cut_positions.append(cut_pos)
            
        cut_positions.sort()

        # Calculate fragment lengths based on cut positions
        fragments = []
        current_pos = 0
        
        # If no cuts, the fragment is the whole DNA
        if not cut_positions:
            return [len(dna_sequence)], []

        for cut in cut_positions:
            length = cut - current_pos
            fragments.append(length)
            current_pos = cut
            
        # Add the final fragment (from last cut to end of DNA)
        fragments.append(len(dna_sequence) - current_pos)
        
        return fragments, cut_positions

def generate_random_dna(min_len=1000, max_len=3000):
    """Generates a random DNA string of arbitrary length."""
    length = random.randint(min_len, max_len)
    return ''.join(random.choice('ATCG') for _ in range(length))

def simulate_gel_electrophoresis(results, ladder, title="In Silico Gel Electrophoresis"):
    """
    Visualizes the fragments on a simulated gel.
    """
    fig, ax = plt.subplots(figsize=(8, 6))
    
    # Visual Styling to match the photo (Dark background, light bands)
    ax.set_facecolor('black')
    fig.patch.set_facecolor('white')
    
    # Prepare Lane Data
    # Lane 0 will be the Size Marker (Ladder)
    lanes = ['Ladder'] + list(results.keys())
    
    # 1. Plot the Ladder
    # We use a logarithmic scale for Y because DNA migrates logarithmically
    for size in ladder:
        # Draw a horizontal line (band)
        # width=0.6 creates a standard lane width
        ax.hlines(y=size, xmin=-0.3, xmax=0.3, color='white', linewidth=2, alpha=0.8)

    # 2. Plot the Enzyme Digests
    for i, enzyme_name in enumerate(results.keys()):
        fragments = results[enzyme_name]['fragments']
        x_center = i + 1  # Shift right by 1 to account for ladder
        
        for frag_size in fragments:
            # Add a slight "glow" effect using alpha (transparency)
            # Thicker lines for larger amounts of DNA (optional, keeping constant here)
            ax.hlines(y=frag_size, xmin=x_center-0.3, xmax=x_center+0.3, 
                     color='cyan', linewidth=2.5, alpha=0.9)

    # Configure Axes
    ax.set_yscale('log') # The magic of electrophoresis: Logarithmic migration
    ax.invert_yaxis()    # Small fragments go to bottom, Large at top
    
    # Set labels
    ax.set_xticks(range(len(lanes)))
    ax.set_xticklabels(lanes, rotation=45)
    ax.set_ylabel('Fragment Size (bp)')
    ax.set_title(title)
    
    # Clean up grid and spines
    ax.grid(False) 
    # Add a subtle grid for size estimation if desired, but standard gels don't have them
    
    plt.tight_layout()
    plt.show()

# --- MAIN EXECUTION ---

# 1. Setup Data
# You can replace this string with a real sequence from NCBI if you wish.
dna_sequence = generate_random_dna(1000, 3000)

print(f"Analyzing DNA Sequence (Length: {len(dna_sequence)} bp)")
print("-" * 50)

# Define Enzymes based on the prompt image
# Note: The cut index is 0-based relative to the sequence string.
enzymes = [
    RestrictionEnzyme("EcoRI",   "GAATTC", 1), # G|AATTC
    RestrictionEnzyme("BamHI",   "GGATCC", 1), # G|GATCC
    RestrictionEnzyme("HindIII", "AAGCTT", 1), # A|AGCTT
    RestrictionEnzyme("TaqI",    "TCGA",   1), # T|CGA
    RestrictionEnzyme("HaeIII",  "GGCC",   2), # GG|CC
]

# A standard DNA Ladder for comparison (bp)
ladder = [100, 200, 300, 400, 500, 750, 1000, 1500, 2000, 3000]

results = {}

# 2. Perform Digestion
for enzyme in enzymes:
    frags, positions = enzyme.digest(dna_sequence)
    results[enzyme.name] = {
        'fragments': frags,
        'cuts': positions
    }
    
    # Output Text Report
    print(f"Enzyme: {enzyme.name}")
    print(f"  Recognition: {enzyme.sequence}")
    print(f"  Number of Cleavages: {len(positions)}")
    print(f"  Cut Positions: {positions}")
    print(f"  Fragment Lengths: {frags}")
    print("-" * 30)

# 3. Simulate Gel
simulate_gel_electrophoresis(results, ladder)